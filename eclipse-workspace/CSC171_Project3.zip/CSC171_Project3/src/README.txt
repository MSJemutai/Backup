Emely Rosa (Submitter), Glenda Garay, Mercy Salome Jemutai
erosa4, ggaray, mjemutai 
Lab Section: MW 12:30-1:45, MW 2:00-3:15, TR 12:30-1:45PM
Project 3: Fireworks
We did not copy code from anyone on this assignment.
 
 COLLABORATORS:
 - Emely Rosa (SUBMITTER)
 - Glenda Garay
 - Mercy Salome Jemutai
 
 Our project allows the user to interact with sliders and drop down menus as well as a launch button to 
 commence a trajectory that displays a firework rendering. 
 
 Extra Credit:
 Random coloring on firework rendering(explosion).
 
 