/*Emely Rosa (Submitter), Glenda Garay, Mercy Salome Jemutai
 * erosa4, ggaray,mjemutai 
 * Lab Section: MW 12:30-1:45, MW 2:00-3:15, TR 12:30-1:45PM
 * Project 3: Fireworks
 */
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class Fireworks extends JFrame implements ActionListener, ChangeListener { // Creation of Listeners
	private static final long serialVersionUID = 1L;

	// Creation of sliders
	public JSlider powerS = new JSlider(5, 200, 150);
	public JSlider timeS = new JSlider(1, 20, 10);
	public JSlider angleS = new JSlider(45, 85, 60);

	// Creation of Labels
	public JLabel powerL = new JLabel("Power: " + "150");
	public JLabel timeL = new JLabel("Time: " + "10");
	public JLabel angleL = new JLabel("Angle: " + "60");

	// Drop menu for colors
	String[] colors = { "Blue", "Red", "Cyan", "Yellow", "Magenta" };
	public JComboBox colorsB = new JComboBox(colors);
	Color color = Color.WHITE; // Initial color of trajectory

	// Drop menu for explosions
	String[] explosions = { "Leaf", "Lasso", "Funnel", "Sparkler", "Loopy" };
	public JComboBox explosionsB = new JComboBox(explosions);
	String explosion;
	JButton launch;

	public Fireworks() {
		JPanel panel1 = new JPanel(new FlowLayout());
		JPanel panel2 = new JPanel();

		launch = new JButton("FIRE!!");
		launch.addActionListener(this);

		// Adding sliders, drop menus, launch button, and labels to panel.
		panel1.add(powerL);
		panel1.add(powerS);
		panel1.add(timeL);
		panel1.add(timeS);
		panel1.add(angleL);
		panel1.add(angleS);
		panel1.add(colorsB);
		panel1.add(explosionsB);
		panel1.add(launch);
		panel2.add(panel1);
		add(panel2);

		// Addition of action and change listeners
		powerS.addChangeListener(this);
		angleS.addChangeListener(this);
		timeS.addChangeListener(this);
		colorsB.addActionListener(this);
		explosionsB.addActionListener(this);

		// Basic building of the frame
		canvas fireArea = new canvas();
		fireArea.setPreferredSize(new Dimension(800, 500));
		setSize(1200, 800);
		add(panel2, BorderLayout.NORTH);
		add(fireArea, BorderLayout.CENTER);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		pack();

	}

	public class canvas extends JPanel {
		private static final long serialVersionUID = 1L;

		@Override
		public void paintComponent(Graphics g) {
			// space where fireworks is drawn and launched
			g.fillRect(0, 0, getWidth(), getHeight());
			Random rand = new Random(256); // Used for random colors.

			// Conversions to calculate projectile
			double angle = Math.toRadians(angleS.getValue());
			double time = timeS.getValue();
			double power = powerS.getValue();
			int velocity = (int) ((power * Math.sin(angle)));
			int startX = 0;
			int startY = 0;
			int finalX = 0;
			int finalY = 0;
			g.setColor(color);
			int numLines = 15;
			int width = 50;
			int height = 100;
			int stepsX = width / numLines;

			for (int i = 0; i < time; i++) {
				int x = (int) ((power * i) * Math.cos(angle));
				int y = ((int) (((velocity * i - (9.8 * i * i)))));
				startX = x;
				startY = getHeight() - y;

				if (i < (power / 9)) {
					if (i == 0) {
						g.fillOval(startX - 20, startY, 20, 20);
					}
					if (i != 0) {
						g.drawLine(startX, startY, finalX, finalY); // Actual drawing of projectile
					}
					finalX = startX;
					finalY = startY;
				}
			}
			// The leaf explosion draws two colorful leaves or roundRectangle.
			if (explosionsB.getSelectedItem().equals("Leaf")) {
				numLines = 3;
				width = 50;
				height = 100;
				stepsX = width / numLines;

				for (int i = 0; i <= 8; i++) {
					Color col = new Color(rand.nextInt(256), rand.nextInt(256), rand.nextInt(256));
					g.setColor(col);

					g.drawRoundRect(finalX + (10 * i), finalY + (10 * i), (finalX / 3) / 2, (finalY / 3) / 2, 6, 6);
					g.drawRoundRect((finalX - (10 * i) - 70), (finalY - (10 * i)) - 40, (finalX / 3) / 2,
							(finalY / 3) / 2, 6, 6);
				}
				// Draws multiple ovals with equal distance from each other.
			} else if (explosionsB.getSelectedItem().equals("Lasso")) {
				numLines = 15;
				width = 50;
				height = 100;
				stepsX = width / numLines;

				for (int i = 0; i <= 30; i++) {
					Color col = new Color(rand.nextInt(256), rand.nextInt(256), rand.nextInt(256));
					g.setColor(col);
					int nextF = finalX + (i / 25);
					g.drawOval(nextF, finalY - (100), width + (stepsX * i), height * 2);
				}
				// Draws ovals in increasing size.
			} else if (explosionsB.getSelectedItem().equals("Funnel")) {
				for (int i = 0; i <= 12; i++) {
					for (int j = 0; j <= 12; j++) {
						Color col = new Color(rand.nextInt(256), rand.nextInt(256), rand.nextInt(256));
						g.setColor(col);
						g.drawOval(finalX - i * 10, finalY - i * 10, 10 * i, 10 * i);
					}
				}
				// Small standard firework (lines)
			} else if (explosionsB.getSelectedItem().equals("Sparkler")) {
				int sX = 0;
				int sY = 0;

				for (int i = 15; i <= 360 - angle; i = i + 15) {
					for (int j = 0; j <= 1; j++) {
						int a = (int) (100 * j * Math.cos(i));
						int b = (int) ((100 * Math.sin(i)) * j - (9.8 * j * j));
						if (j != 0) {
							g.drawLine(a + finalX, finalY - b, sX, sY);
						}

						sX = a + finalX;
						sY = finalY - b;
					}
				}
				// Draws concentric circles
			} else if (explosionsB.getSelectedItem().equals("Loopy")) {
				int numCircles = 12;
				for (int i = 0; i < numCircles; i++) {
					Color col = new Color(rand.nextInt(256), rand.nextInt(256), rand.nextInt(256));
					g.setColor(col);
					g.drawOval(finalX - (i * 10), finalY - (i * 10), i * 20, i * 20);
				}
			}
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == launch) {
			repaint();
		} else if (e.getSource() == colorsB) {
			String colorS = (String) colorsB.getSelectedItem();
			switch (colorS) {
			// setting the color based on drop down menu selection
			case "Blue":
				color = Color.BLUE;
				break;
			case "Red":
				color = Color.RED;
				break;
			case "Cyan":
				color = Color.CYAN;
				break;
			case "Yellow":
				color = Color.YELLOW;
				break;
			case "Magenta":
				color = Color.MAGENTA;
				break;

			}

			// Explosion selection
		} else if (e.getSource() == explosionsB) {
			explosion = (String) explosionsB.getSelectedItem();
		}
	}

	@Override
	public void stateChanged(ChangeEvent e) {
		if (e.getSource().equals(timeS)) {
			timeL.setText("Time: " + timeS.getValue());
		} else if (e.getSource().equals(angleS)) {
			angleL.setText("Angle: " + angleS.getValue());
		} else if (e.getSource().equals(powerS)) {
			powerL.setText("Power: " + powerS.getValue());
		}

	}

	public static void main(String[] args) {
		Fireworks fire = new Fireworks();

	}

}
