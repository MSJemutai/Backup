Mercy Salome Jemutai

mjemutai@u.rochester.edu
Lab 2; Tue Thur 4.50-6.05 PM ; Generics.
The lab is on generics. It explores the differences between generic and non-generic methods 
and  the features of generics.

For this lab, I went doing one question at time while checking that it was working. I spent some time
doing more studying on generics though.

It was a simple lab, except I had issues with using terminal to check my source code for error.
