Mercy Salome Jemutai
mjemutai@.rochester.edu
Lab Partner: Carolina Lion He
clionhe@u.rochester.edu 
Lab 3

The lab is on collections: arrays and arraylists and the different operations that 
can be achieved given the two such as summing across rows.

The files contained are the source code for Task1, Task2, and Task3; README; and testing scripts



For Task1 part one, do not add space after semicolon!




