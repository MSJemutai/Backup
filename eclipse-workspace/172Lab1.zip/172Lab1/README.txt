Mercy Salome Jemutai (haven't found a lab partner!)
mjemutai@u.rochester.edu

This lab writing two programs, one that has a method that checks if two strings given are anagrams, 
and the other checking if they are are a rotation of each other.
I have two classes, task1 and task2, as per the order of the assignment questions.

Thanks.




