//MY LINKED LIST CLASS
public class LinkedList<AnyType> implements SimpleLinkedList<AnyType>{
	
	private MyNode<AnyType> head;

	public LinkedList() {
		
		super();
		//data = null;    ///MyNode<AnyType>.this.data =null
		
		head=null;
		
		
	}
	
	@Override
	public boolean isEmpty() {
		
		if( head==null) {
			return true;	
		}else {
			return false;
		}
		
		
			}

	
	@Override
	public void insert(AnyType x) {
		
		
	}

	@Override
	public void delete(AnyType x) {
		
		
	}

	@Override
	public boolean contains(AnyType x) {
		
		return false;
	}

	@Override
	public AnyType lookup(AnyType x) {
		
		return null;
	}

	
	@Override
	public void printList() {
		
		
	}
	
	
	
	
	
public static void main(String[] args) {
		

	}

}
