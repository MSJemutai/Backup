//NODE CLASS

public class MyNode<AnyType> {


	public AnyType data;
	public MyNode<AnyType> next;

	public MyNode(AnyType data, MyNode<AnyType> next)
	{
		this.data = data;
		this.next = next;
	}


}